import numpy as np
import timeit
from scipy.sparse.linalg import svds, eigs
from sklearn.cluster import KMeans

# spectral clustering algorithmn###############
def spectralClustering(A,K,normalize=True):
    # spectral clustering with permutation
    star_time= timeit.default_timer()
    # the left eigenvalue of A 
    u,s,vt= svds(A, k=K)
    # sort the eigenvalues in decreasingly
    Ik= np.argsort (-s)
    V=u[:,Ik[0:K]]
    # normalized each row vector of V
    if normalize==True:
        V=  V / (np.linalg.norm(V, axis=-1)[:, np.newaxis]+1e-8)
        
    kmeansfit= KMeans(K).fit (V)
    # estimates the community labels by k-means clustering 
    Labels_Hat = kmeansfit.labels_
    end_time= timeit.default_timer()
    time_used= end_time- star_time
    re= list([Labels_Hat, time_used])
    return re

