import numpy as np # linear algebra
import random
##generate network from DCSBM##################################
def DCSBM( N,clusters_distribution,rho,beta,alpha_vec,del_0d = False):
     # N: total network size 
    # clusters_distribution: paramters in multinormial distribution
    # rho: network density
    # beta: out-in ratio parameter
    # alpha_vec: the degree heterogeniety parameter
    
    K=len(clusters_distribution)
    #the connectivity matrix
    Theta= np.ones((K,K))+ (1/beta -1)*np.identity(K)
    # the connectivity matrix
    connection_matrix= rho*Theta\
    /((clusters_distribution.T.dot(Theta).dot(clusters_distribution)))
    
    label_clusters= np.arange(K)
    
    clusters= np.random.choice(label_clusters,N, p=clusters_distribution, replace=True)
    
    RM= np.random.uniform(0,1,N**2).reshape((N,N))
    
    RM= np.triu(RM)+np.triu(RM).T-np.diag(np.diag(RM))

    detM= connection_matrix[clusters,:][:,clusters]
    # the probability matrix of dcsbm
    Prob_mat=  np.diag(alpha_vec).dot(detM).dot(np.diag(alpha_vec)) 
    
    A= (RM< Prob_mat) + 0.0 
    A=A-np.diag(np.diag(A))
    labels=clusters
    # delete isolate nodes
    if del_0d:
        Ind_0= list(np.where(np.sum(A,1)!=0))[0]
        Adj= A[Ind_0][:,Ind_0]
        labels= clusters[Ind_0]
        re=list([labels, Adj])
    else:
        re=list([labels, A])
    return re
