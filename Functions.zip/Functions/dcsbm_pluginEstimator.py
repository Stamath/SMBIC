import numpy as np 
from scipy.sparse.linalg import svds, eigs

def dcsbm_pluginEstimator(A,K,labels, Vfit):
    #A: the adjacency matrix 
    #K: the candidate number of communities
    # labels: the estimated labels 
    # Vifit: the selected node set 
    
    N=np.shape(A)[0]
    # a estimator of connectivity matrix 
    whB= np.zeros((K,K))
    # the fitting data 
    Afit=A[:,Vfit]
    # estimates the heterogeneity paramter 
    u,s,vt= svds(Afit, k=K)
    # sort the eigenvalues in decreasingly
    Ik= np.argsort(-s)
    U=u[:,Ik[0:K]]
    psi= np.linalg.norm(U, axis=-1)[:, np.newaxis]
    
    for k in range(0, K):
        # the node index in the kth group ###################
        Ck= list(np.where(labels == k))[0]
        # the selected data in the k cluster
        C1k= list((set(Vfit)& set(Ck)))
        # the unselected nodes in the k cluster
        C2k= np.setdiff1d(Ck,C1k)
        # estimates the degree paramters
        psi1k= psi[C1k]
        psi2k= psi[C2k]
        psik= psi[Ck]
        
        for l in range(k, K):
            if l==k:
                Ein= 0.5*np.sum(A[C1k][:,C1k])
                Eout= np.sum(A[C2k][:,C1k])
                Eall=Ein+Eout
                
                matpsi1k= psi1k.dot(psi1k.T)
                matpsi1k= matpsi1k-np.diag(np.diag(matpsi1k))
                
                matpsi2k= psi2k.dot(psi1k.T)
                nin= 0.5*np.sum(matpsi1k)
                nout= np.sum(matpsi2k)
                nall= nin +nout
                
            else:
                Cl= list(np.where(labels == l))[0]
                C1l=list((set(Vfit)& set(Cl)))
                
                psi1l=psi[C1l]
                matpsikl= psik.dot(psi1l.T)
                Eall= np.sum( A[Ck][:,C1l])
                nall= np.sum(matpsikl)
            # estimates the connectivity probability between the (k,l) clusters    
            whB[k,l]= Eall/(nall+1e-10)
            
    whB=np.triu(whB)+np.triu(whB).T-np.diag(np.diag(whB))
    
    psi_hat=psi.reshape((N,))
    
    paramters= list([whB,psi_hat])
    
    return paramters

            
