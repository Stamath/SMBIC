import numpy as np
#########################################################
def Evaluation( whKseq, K):
    # evaluation the peformance of model selection algorithm
    #1. Prob
    #2. Mean
    R=len(whKseq)
    Prob=  len(list(np.where(whKseq== K))[0])/R
    Mean= np.mean(whKseq)
    Accuracy=np.array([Prob,Mean])
    return Accuracy