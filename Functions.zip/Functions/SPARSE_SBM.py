import numpy as np
import random
##generate network from SBM##################################
def SPARSE_SBM(N,clusters_distribution,rho,beta):  
    # N: total network size 
    # clusters_distribution: paramters in multinormial distribution
    # rho: network density
    # beta: out-in ratio parameter
    K=len(clusters_distribution)
    #the connectivity matrix
    Theta= np.ones((K,K))+ (1/beta -1)*np.identity(K)
    
    connection_matrix= rho*Theta\
    /((clusters_distribution.T.dot(Theta).dot(clusters_distribution)))
    
    label_clusters= np.arange(K)
    # true community label vector
    clusters= np.random.choice(label_clusters,N, p=clusters_distribution, replace=True)
    
    RM= np.random.uniform(0,1,N**2).reshape((N,N))
    
    RM= np.triu(RM)+np.triu(RM).T-np.diag(np.diag(RM))

    detM= connection_matrix[clusters,:][:,clusters]
    # create adjacency matrix 
    A= (RM< detM) + 0.0 
    A=A-np.diag(np.diag(A))
    
    labels=clusters

    re=list([labels, A])
    return re
