import numpy as np # linear algebra
import timeit
from spectralClustering import spectralClustering
from sbm_pluginEstimator import *

# construct subsampling based network cross validation #######################
def SMBIC_sbm(A,mathcalK,n):
    #sampleMethod=srSample
    time_star= timeit.default_timer()
    # the size of entire network nodes 
    N=np.shape(A)[0]
    # mathcalK is the candidate set of K
    Kmax= len(mathcalK)
    # loss value of each candidate k
    smBIC= np.zeros((Kmax,))
    
    mathcalS= np.random.choice (np.arange(N), n, replace=False)
    # the subadjacency matrix 
    AS=A[:,mathcalS].astype(float)
    for k in range(0,Kmax) :
        # the candidate value of k
        K= mathcalK[k]
        # estimate the community label by spectral clustering 
        whg=spectralClustering(AS,K)[0]
        # obtain the estimate of the connectivity matrix 
        whB= sbm_pluginEstimator(A,K,whg, mathcalS)
        
        K_I= np.identity(K)
        # the labels of selected nodes
        sample_labels= whg[mathcalS]
        # the membership matrix of selected samples
        Z_s=K_I[sample_labels,:]
        # the probability matrix of selected nodes
        Prob_s= Z_s.dot(whB).dot(Z_s.T)
        Prob_s[Prob_s==0]=1e-8
        Prob_s[Prob_s>1]=1-1e-8
        
        A_s=AS[mathcalS]   
        # the likelihood based on selected nodes 
        Inlikelihood= np.sum(A_s*np.log(Prob_s)+(1-A_s)*np.log(1-Prob_s))/2
        # the unselected nodeset 
        completeS= np.setdiff1d(np.arange(0,N),mathcalS)
        # estimates the labels of unselected nodes 
        unselected_labels= whg[completeS]
        # the community membership matrix of unselected nodes 
        Z_us= K_I[unselected_labels,:]
        # the connectivity probability between selected and unselected nodes 
        Prob_us= Z_us.dot(whB).dot(Z_s.T)
        Prob_us[Prob_us==0]=1e-8
        Prob_us[Prob_us>=1]= 1-1e-8
        # the observations between selected nodes and unselected nodes
        A_us= AS[completeS]
        # the likelihood 
        Outlikelihood= np.sum(A_us*np.log(Prob_us)+ (1-A_us)*np.log(1-Prob_us))
        # the likelihood based on the subadjacency matrix
        valuek= Inlikelihood+ Outlikelihood
        # the number of independent edge variables in the subadjacency matrix
        M = N*n -n*(n+1)/2
        smBIC[k]= valuek-K*(K+1)/4*np.log(M)- n*np.log(K)
    
    # selecte the optimal number of communities    
    whK= mathcalK[np.argmax(smBIC[np.arange(0,k)])]
    time_end= timeit.default_timer()
    time_used= time_end- time_star
    re=list([whK,time_used])
    
    return re