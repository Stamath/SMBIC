import numpy as np # linear algebra
import timeit
from spectralClustering import spectralClustering
from dcsbm_pluginEstimator import *

####SMBIC algorithm for DCSBM #########################
def SMBIC_dcsbm(A,mathcalK,n):
    #sampleMethod=srSample
    time_star= timeit.default_timer()
    # the size of entire network nodes 
    N=np.shape(A)[0]
    # mathcalK is the candidate set of K
    Kmax= len(mathcalK)
    # loss value of each candidate k
    smBIC= np.zeros((Kmax,))
    
    mathcalS= np.random.choice (np.arange(N), n, replace=False)
    #print("size of mathcalS",ns)
    AS=A[:,mathcalS].astype(float)
    for k in range(0,Kmax) :
        #k=1
        #print("communities k",k)
        # the candidate value of k
        K= mathcalK[k]
        whg=spectralClustering(AS,K)[0]
        #clusteringAccuracy(Gplabel, whg)
        # obtain the estimate of the block matrix
        # est_results= pluginEstimator(A,K,whg, mathcalS)
        est_results= dcsbm_pluginEstimator(A,K,whg, mathcalS)
        whB= est_results[0]
        # estimated probabilities between selected 
        # the community labels of selected nodes
        K_I= np.identity(K)
        # the labels of selected nodes
        sample_labels= whg[mathcalS]
        # the membership matrix of selected samples
        Z_s=K_I[sample_labels,:]
        Prob_s= Z_s.dot(whB).dot(Z_s.T)
        
        Psi_hat= est_results[1]
        Psi_s= Psi_hat[mathcalS]
        
        Prob_s= np.diag(Psi_s).dot(Prob_s).dot(np.diag(Psi_s))
        
        Prob_s[Prob_s==0]=1e-8
        Prob_s[Prob_s>1]=1-1e-8
        A_s=AS[mathcalS]   
        
        # the likelihood of selected nodes 
        Inlikelihood= np.sum(A_s*np.log(Prob_s)+(1-A_s)*np.log(1-Prob_s))/2
        # the unselected node set
        completeS= np.setdiff1d(np.arange(0,N),mathcalS)
        
        unselected_labels= whg[completeS]
        
        Z_us= K_I[unselected_labels,:]
        Prob_us= Z_us.dot(whB).dot(Z_s.T)
        
        Psi_us= Psi_hat[completeS]
        Prob_us= np.diag(Psi_us).dot(Prob_us).dot(np.diag(Psi_s))
        
        Prob_us[Prob_us==0]=1e-8
        Prob_us[Prob_us>=1]= 1-1e-8
        
        A_us= AS[completeS]
        
        Outlikelihood= np.sum(A_us*np.log(Prob_us)+ (1-A_us)*np.log(1-Prob_us))
        # likelihood function#####################
        valuek= Inlikelihood+ Outlikelihood
       
        M = N*n-n*(n+1)/2
        smBIC[k]= valuek- K*(K+1)/4*np.log(M)- n*np.log(K)
        #print("the number of communities",K)
        #print( 'SMBIC',smBIC[k])
    # write out each k results
    # the selected K     
    whK= mathcalK[np.argmax(smBIC[np.arange(0,k)])]
    time_end= timeit.default_timer()
    time_used= time_end- time_star
    re=list([whK,time_used])

    return re