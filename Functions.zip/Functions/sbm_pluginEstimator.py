import numpy as np

#########################################
def sbm_pluginEstimator(A,K,labels,Vfit):
    # A: adjacency matrix 
    # K: the candidate number of communities 
    # labels: the estimated label vector 
    # Vfit: a subset of nodes for fitting models 
    # return a estimtor of connectivity matrix 
    
    #the connectivity matrix
    P_Hat= np.zeros((K,K))
    for k in range(0, K):
        # the node index in the kth group ###################
        Ck= list(np.where(labels == k))[0]
        # the fit data in the k cluster
        C1k= list((set(Vfit)& set(Ck)))
        # the unfitted data in the k cluster
        C2k= np.setdiff1d(Ck,C1k)
        n1k= len(C1k)
        n2k= len(C2k)
        nk= len(Ck)
        for l in range(k, K):
            # inter-community estimator 
            if l==k:
                Ein= 0.5*np.sum(A[C1k,:][:,C1k])
                Eout= np.sum(A[C2k,:][:,C1k])
                Eall=Ein+Eout
                nin=0.5*(n1k-1)*n1k
                nout=n2k*n1k
                nall= nin +nout
            else:
                Cl= list(np.where(labels == l))[0]
                C1l=list((set(Vfit)& set(Cl)))
                n1l=len(C1l)
                Eall= np.sum( A[Ck,:][:,C1l])
                nall= nk*n1l
            # estimte the connectivity probability between (k,l) clusters     
            P_Hat[k,l]= Eall/(nall+1e-10)
     # symmetric        
    P_Hat=np.triu(P_Hat)+np.triu(P_Hat).T-np.diag(np.diag(P_Hat))    
    
    return P_Hat


